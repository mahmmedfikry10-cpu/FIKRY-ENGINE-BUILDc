# Build FIKRY ENGINE V1 APK from an Android phone (GitHub Actions)

## What you need
- A GitHub account.
- The project ZIP from this package.
- A browser on your Android phone.

## One-time setup
1. Open https://github.com/new and create a repository named `FIKRY-ENGINE-BUILD`.
2. Public is easiest for a first build. Do not upload passwords, API keys, or private files.
3. Open the new repository and choose **Add file > Upload files**.
4. Upload `FIKRY_ENGINE_V1_AndroidStudio.zip` from this package.
5. Commit the upload.
6. In the repository, choose **Add file > Create new file**.
7. In the filename field enter exactly: `.github/workflows/android-apk.yml`
8. Open the separate `android-apk.yml` file included in this package, copy all its text, and paste it into GitHub's editor.
9. Commit the new file.
10. Open the repository's **Actions** tab. Select **Build FIKRY ENGINE Android APK** and press **Run workflow** if it has not started automatically.
11. Wait for the workflow to finish with a green check.
12. Open the completed run, scroll to **Artifacts**, and download `FIKRY-ENGINE-V1-debug-apk`.
13. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Tap it to install. If Android asks, allow your browser/file manager to install unknown apps.

## Notes
- GitHub Actions builds the APK on a cloud Linux runner; your phone does not compile the C++ code.
- Public repositories normally have free Actions minutes, subject to GitHub's current usage limits and policies. Private repositories have plan-dependent included minutes.
- The generated APK is a debug build, suitable for testing, not a signed Play Store release.
- If the workflow fails, open the failed run and copy the first red error section so it can be diagnosed.
