package com.fikry.engine;

public final class NativeEngine {
    static { System.loadLibrary("fikry_engine"); }
    private NativeEngine() {}
    public static native void init();
    public static native void resize(int width, int height);
    public static native void render();
    public static native void orbit(float dx, float dy);
    public static native void zoom(float amount);
    public static native void resetCamera();
}
