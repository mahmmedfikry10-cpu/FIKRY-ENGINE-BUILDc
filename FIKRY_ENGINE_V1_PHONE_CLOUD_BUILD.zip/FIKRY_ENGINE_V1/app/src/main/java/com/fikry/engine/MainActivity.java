package com.fikry.engine;

import android.app.Activity;
import android.os.Bundle;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Button;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private EngineView engineView;
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8, 12, 22));
        engineView = new EngineView(this);
        root.addView(engineView, new FrameLayout.LayoutParams(-1, -1));

        TextView brand = new TextView(this);
        brand.setText("FIKRY ENGINE  /  V1.0");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(13);
        brand.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        brand.setLetterSpacing(0.08f);
        brand.setPadding(24, 16, 24, 16);
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0xCC111C30);
        pill.setCornerRadius(28);
        brand.setBackground(pill);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP|Gravity.LEFT);
        bp.setMargins(18, 18, 0, 0);
        root.addView(brand, bp);

        status = new TextView(this);
        status.setText("NATIVE C++  •  OPENGL ES 3.0  •  ANDROID");
        status.setTextColor(0xFF9DB5D8);
        status.setTextSize(10);
        status.setPadding(18, 10, 18, 10);
        status.setBackgroundColor(0x99111C30);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM|Gravity.LEFT);
        sp.setMargins(18, 0, 0, 18);
        root.addView(status, sp);

        Button reset = new Button(this);
        reset.setText("RESET VIEW");
        reset.setTextSize(11);
        reset.setTextColor(Color.WHITE);
        reset.setAllCaps(false);
        reset.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF5145CD));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP|Gravity.RIGHT);
        rp.setMargins(0, 16, 18, 0);
        root.addView(reset, rp);
        reset.setOnClickListener(v -> engineView.resetCamera());

        TextView hint = new TextView(this);
        hint.setText("DRAG TO ORBIT   •   PINCH TO ZOOM");
        hint.setTextColor(0xFFE0E8F5);
        hint.setTextSize(10);
        hint.setPadding(16, 9, 16, 9);
        hint.setBackgroundColor(0x88111C30);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM|Gravity.RIGHT);
        hp.setMargins(0, 0, 18, 18);
        root.addView(hint, hp);

        setContentView(root);
    }

    @Override protected void onPause() { super.onPause(); if (engineView != null) engineView.onPause(); }
    @Override protected void onResume() { super.onResume(); if (engineView != null) engineView.onResume(); }

    private static class EngineView extends GLSurfaceView {
        private final EngineRenderer renderer;
        private float oldX, oldY, oldDistance;
        EngineView(Activity activity) {
            super(activity);
            setEGLContextClientVersion(3);
            renderer = new EngineRenderer();
            setRenderer(renderer);
            setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        }
        void resetCamera() { queueEvent(() -> NativeEngine.resetCamera()); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getPointerCount() >= 2) {
                float dx = e.getX(0)-e.getX(1), dy = e.getY(0)-e.getY(1);
                float d = (float)Math.sqrt(dx*dx+dy*dy);
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE && oldDistance > 0) {
                    final float delta = (oldDistance-d) * 0.012f;
                    queueEvent(() -> NativeEngine.zoom(delta));
                }
                oldDistance = d;
                return true;
            }
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: oldX=e.getX(); oldY=e.getY(); oldDistance=0; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx=e.getX()-oldX, dy=e.getY()-oldY;
                    oldX=e.getX(); oldY=e.getY();
                    queueEvent(() -> NativeEngine.orbit(dx*0.006f, dy*0.006f));
                    return true;
                case MotionEvent.ACTION_UP: oldDistance=0; return true;
            }
            return true;
        }
    }

    private static class EngineRenderer implements GLSurfaceView.Renderer {
        @Override public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl,
                                                javax.microedition.khronos.egl.EGLConfig config) {
            NativeEngine.init();
        }
        @Override public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl, int w, int h) {
            NativeEngine.resize(w,h);
        }
        @Override public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) {
            NativeEngine.render();
        }
    }
}
