#include "Renderer.h"
#include <vector>
#include <cmath>
namespace fikry {
static const char* VS = R"(#version 300 es
layout(location=0) in vec3 aPos;
uniform mat4 uMVP;
void main(){ gl_Position=uMVP*vec4(aPos,1.0); }
)";
static const char* FS = R"(#version 300 es
precision mediump float;
uniform vec4 uColor;
out vec4 fragColor;
void main(){ fragColor=uColor; }
)";
static GLuint compile(GLenum type,const char* src){
    GLuint s=glCreateShader(type); glShaderSource(s,1,&src,nullptr); glCompileShader(s);
    GLint ok=0; glGetShaderiv(s,GL_COMPILE_STATUS,&ok);
    if(!ok){ glDeleteShader(s); return 0; } return s;
}
bool Renderer::initialize(){
    GLuint vs=compile(GL_VERTEX_SHADER,VS), fs=compile(GL_FRAGMENT_SHADER,FS);
    if(!vs||!fs) return false;
    program_=glCreateProgram(); glAttachShader(program_,vs); glAttachShader(program_,fs);
    glLinkProgram(program_); glDeleteShader(vs); glDeleteShader(fs);
    GLint ok=0; glGetProgramiv(program_,GL_LINK_STATUS,&ok); if(!ok) return false;
    mvpLoc_=glGetUniformLocation(program_,"uMVP"); colorLoc_=glGetUniformLocation(program_,"uColor");
    buildGeometry(); glEnable(GL_DEPTH_TEST); glEnable(GL_CULL_FACE); glCullFace(GL_BACK);
    glClearColor(0.035f,0.055f,0.095f,1.0f); return true;
}
void Renderer::resize(int w,int h){ glViewport(0,0,w,h); }
void Renderer::buildGeometry(){
    std::vector<float> v;
    auto tri=[&](float ax,float ay,float az,float bx,float by,float bz,float cx,float cy,float cz){
        v.insert(v.end(),{ax,ay,az,bx,by,bz,cx,cy,cz});
    };
    // Unit cube, 12 triangles.
    const float p=0.5f;
    const float faces[][9]={
      {-p,-p,p,p,-p,p,p,p,p},{-p,-p,p,p,p,p,-p,p,p},
      {p,-p,-p,-p,-p,-p,-p,p,-p},{p,-p,-p,-p,p,-p,p,p,-p},
      {-p,-p,-p,-p,-p,p,-p,p,p},{-p,-p,-p,-p,p,p,-p,p,-p},
      {p,-p,p,p,-p,-p,p,p,-p},{p,-p,p,p,p,-p,p,p,p},
      {-p,p,p,p,p,p,p,p,-p},{-p,p,p,p,p,-p,-p,p,-p},
      {-p,-p,-p,p,-p,-p,p,-p,p},{-p,-p,-p,p,-p,p,-p,-p,p}
    };
    for(auto &f:faces) tri(f[0],f[1],f[2],f[3],f[4],f[5],f[6],f[7],f[8]);
    vertexCount_=static_cast<GLsizei>(v.size()/3);
    glGenVertexArrays(1,&vao_); glGenBuffers(1,&vbo_);
    glBindVertexArray(vao_); glBindBuffer(GL_ARRAY_BUFFER,vbo_);
    glBufferData(GL_ARRAY_BUFFER,v.size()*sizeof(float),v.data(),GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);
    glBindVertexArray(0);
}
void Renderer::draw(float yaw,float pitch,float distance){
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    if(!program_) return;
    float cp=std::cos(pitch), sp=std::sin(pitch);
    Vec3 eye{std::sin(yaw)*cp*distance, std::sin(pitch)*distance+3.0f, std::cos(yaw)*cp*distance};
    Mat4 proj=perspective(0.92f, 1.7f, 0.1f, 250.0f);
    Mat4 view=lookAt(eye,{0,0,0},{0,1,0});
    glUseProgram(program_); glBindVertexArray(vao_);
    // Ground grid: thin cube instances represented as scaled cubes.
    for(int i=-10;i<=10;i++){
        for(int axis=0;axis<2;axis++){
            Mat4 model=identity();
            if(axis==0){ model.m[0]=20.0f; model.m[5]=0.012f; model.m[10]=0.012f; model.m[13]=-0.55f; model.m[14]=i*1.0f; }
            else { model.m[0]=0.012f; model.m[5]=0.012f; model.m[10]=20.0f; model.m[12]=i*1.0f; model.m[13]=-0.55f; }
            Mat4 mvp=multiply(proj,multiply(view,model));
            glUniformMatrix4fv(mvpLoc_,1,GL_FALSE,mvp.m);
            glUniform4f(colorLoc_,(i==0?0.15f:0.10f),(i==0?0.55f:0.22f),(i==0?0.75f:0.32f),1);
            glDrawArrays(GL_TRIANGLES,0,vertexCount_);
        }
    }
    const float positions[4][3]={{0,0,0},{-2,0,1},{2,0,-1},{0,1.4f,-3}};
    const float scales[4][3]={{1,1,1},{0.65f,0.65f,0.65f},{0.8f,0.8f,0.8f},{0.5f,1.4f,0.5f}};
    const float colors[4][4]={{0.35f,0.30f,0.95f,1},{0.10f,0.75f,0.95f,1},{0.95f,0.42f,0.20f,1},{0.20f,0.85f,0.55f,1}};
    for(int i=0;i<4;i++){
        Mat4 model=identity(); model.m[0]=scales[i][0]; model.m[5]=scales[i][1]; model.m[10]=scales[i][2];
        model.m[12]=positions[i][0]; model.m[13]=positions[i][1]; model.m[14]=positions[i][2];
        Mat4 mvp=multiply(proj,multiply(view,model));
        glUniformMatrix4fv(mvpLoc_,1,GL_FALSE,mvp.m); glUniform4fv(colorLoc_,1,colors[i]);
        glDrawArrays(GL_TRIANGLES,0,vertexCount_);
    }
    glBindVertexArray(0);
}
}
