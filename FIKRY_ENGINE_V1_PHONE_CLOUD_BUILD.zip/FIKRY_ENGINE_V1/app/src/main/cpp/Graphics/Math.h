#pragma once
#include <cmath>
namespace fikry {
struct Vec3 { float x,y,z; };
struct Mat4 { float m[16]; };
Mat4 identity();
Mat4 perspective(float fovy, float aspect, float nearZ, float farZ);
Mat4 lookAt(Vec3 eye, Vec3 center, Vec3 up);
Mat4 multiply(const Mat4& a, const Mat4& b);
}
