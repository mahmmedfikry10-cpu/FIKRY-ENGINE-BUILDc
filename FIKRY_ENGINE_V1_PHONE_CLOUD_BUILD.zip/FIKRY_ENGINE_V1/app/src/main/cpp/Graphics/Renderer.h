#pragma once
#include <GLES3/gl3.h>
#include "Math.h"
namespace fikry {
class Renderer {
public:
    bool initialize();
    void resize(int width,int height);
    void draw(float yaw,float pitch,float distance);
private:
    GLuint program_=0, vao_=0, vbo_=0;
    GLint mvpLoc_=-1, colorLoc_=-1;
    GLsizei vertexCount_=0;
    void buildGeometry();
};
}
