#include <jni.h>
#include "../Core/Engine.h"

extern "C" {
JNIEXPORT void JNICALL Java_com_fikry_engine_NativeEngine_init(JNIEnv*, jclass) {
    fikry::Engine::instance().initialize();
}
JNIEXPORT void JNICALL Java_com_fikry_engine_NativeEngine_resize(JNIEnv*, jclass, jint w, jint h) {
    fikry::Engine::instance().resize(w,h);
}
JNIEXPORT void JNICALL Java_com_fikry_engine_NativeEngine_render(JNIEnv*, jclass) {
    fikry::Engine::instance().render();
}
JNIEXPORT void JNICALL Java_com_fikry_engine_NativeEngine_orbit(JNIEnv*, jclass, jfloat dx, jfloat dy) {
    fikry::Engine::instance().orbit(dx,dy);
}
JNIEXPORT void JNICALL Java_com_fikry_engine_NativeEngine_zoom(JNIEnv*, jclass, jfloat amount) {
    fikry::Engine::instance().zoom(amount);
}
JNIEXPORT void JNICALL Java_com_fikry_engine_NativeEngine_resetCamera(JNIEnv*, jclass) {
    fikry::Engine::instance().resetCamera();
}
}
