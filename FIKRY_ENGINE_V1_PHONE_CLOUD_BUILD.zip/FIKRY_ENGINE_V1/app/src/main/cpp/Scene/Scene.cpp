#include "Scene.h"
namespace fikry {
EntityId Scene::createEntity(const std::string& name){
    Entity e; e.id=nextId_++; e.name=name; entities_.push_back(e); return e.id;
}
}
