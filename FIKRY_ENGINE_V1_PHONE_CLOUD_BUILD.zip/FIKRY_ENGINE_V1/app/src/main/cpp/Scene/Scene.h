#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace fikry {
using EntityId = std::uint32_t;
struct Transform { float position[3]{0,0,0}; float rotation[3]{0,0,0}; float scale[3]{1,1,1}; };
struct Entity { EntityId id=0; std::string name; Transform transform; };
class Scene {
public:
    EntityId createEntity(const std::string& name);
    const std::vector<Entity>& entities() const { return entities_; }
private:
    EntityId nextId_=1;
    std::vector<Entity> entities_;
};
}
