cmake_minimum_required(VERSION 3.22.1)
project(fikry_engine LANGUAGES CXX)

add_library(fikry_engine SHARED
    Platform/JniBridge.cpp
    Core/Engine.cpp
    Graphics/Renderer.cpp
    Graphics/Math.cpp
    Scene/Scene.cpp
)

target_include_directories(fikry_engine PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_compile_features(fikry_engine PRIVATE cxx_std_17)
target_compile_options(fikry_engine PRIVATE -Wall -Wextra -Werror=return-type)

find_library(log-lib log)
find_library(gles-lib GLESv3)
find_library(android-lib android)

target_link_libraries(fikry_engine ${gles-lib} ${log-lib} ${android-lib})
