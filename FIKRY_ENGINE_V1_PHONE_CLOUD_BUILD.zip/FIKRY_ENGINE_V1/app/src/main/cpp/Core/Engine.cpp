#include "Engine.h"
#include <android/log.h>
#include <algorithm>
#define LOG_TAG "FIKRY_ENGINE"
namespace fikry {
Engine& Engine::instance(){ static Engine e; return e; }
void Engine::initialize(){
    bool ok=renderer_.initialize();
    __android_log_print(ANDROID_LOG_INFO,LOG_TAG,"FIKRY ENGINE V1 renderer: %s",ok?"ready":"failed");
}
void Engine::resize(int w,int h){ renderer_.resize(w,h); }
void Engine::render(){ renderer_.draw(yaw_,pitch_,distance_); }
void Engine::orbit(float dx,float dy){
    yaw_+=dx; pitch_=std::clamp(pitch_+dy,-1.15f,1.15f);
}
void Engine::zoom(float amount){ distance_=std::clamp(distance_+amount,3.0f,35.0f); }
void Engine::resetCamera(){ yaw_=0.65f; pitch_=0.35f; distance_=10.0f; }
}
