#pragma once
#include "../Graphics/Renderer.h"
namespace fikry {
class Engine {
public:
    static Engine& instance();
    void initialize();
    void resize(int w,int h);
    void render();
    void orbit(float dx,float dy);
    void zoom(float amount);
    void resetCamera();
private:
    Renderer renderer_;
    float yaw_=0.65f, pitch_=0.35f, distance_=10.0f;
};
}
